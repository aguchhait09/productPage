export default {
  nav: "/assets/nav.svg",
  home: "/assets/home_image.avif",
  home1: "/assets/home2.avif",
  home2: "/assets/home3.avif",
  home3: "/assets/home4.avif",
  home4: "/assets/home5.avif",
  home_avatar1: "/assets/home_avatar1.avif",
  person1: "/assets/person1.avif",
  person2: "/assets/person2.avif",
  person3: "/assets/person3.avif",

};