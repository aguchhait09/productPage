import asset from "@/json/asset";
import Wrapper from "@/layout/Wrapper/Wrapper";
import { Avatar, Container, Grid, Typography } from "@mui/material";
import Link from "next/link";
import styles from "@/styles/about.module.scss"


export default function Home() {
  return (
    <Wrapper>
      <Container sx={{ my: 10 }}>
        <Grid container rowSpacing={1} columnSpacing={{ xs: 1, sm: 2, md: 3 }}>
          <Grid item xs={6} className={styles.grow}>
            <img src={asset?.home} alt="" width="500" height="400" style={{ borderRadius: "2%" }} />
            <Link href="/technology" style={{ textDecoration: "none" }}><Typography sx={{ fontSize: "15px" }}>TECHNOLOGY</Typography></Link>
            <Link href="/technology" style={{ textDecoration: "none" }}><Typography sx={{ fontSize: "20px", color: "black", mr: 2 }}>Architectural Engineering Wonders of the modern era for your Inspiration</Typography></Link>
            <div><Link href=""><Avatar alt="Remy Sharp" src={asset?.home_avatar1} sx={{ float: "left" }} /> <Typography variant="body2" color="text.secondary" sx={{ float: "right", mr: 35, mt: 2 }}>Mario Sanchez October 21, 2022</Typography>
            </Link></div>
          </Grid>
          <Grid item xs={6} className={styles.grow}>
            <img src={asset?.home1} alt="" width="500" height="400" style={{ borderRadius: "2%" }} />
            <Link href="/technology" style={{ textDecoration: "none" }}><Typography sx={{ fontSize: "15px" }}>LIFESTYLE</Typography></Link>
            <Link href="/technology" style={{ textDecoration: "none" }}><Typography sx={{ fontSize: "20px", color: "black", mr: 2 }}>5 Effective Brain Recharging Activities No One is Talking About</Typography></Link>
            <div style={{ display: "flex" }}><Link href=""><Avatar alt="Remy Sharp" src={asset?.home_avatar1} sx={{ float: "left" }} /> <Typography variant="body2" color="text.secondary" sx={{ float: "right", mr: 35, mt: 2 }}>Mario Sanchez October 21, 2022</Typography>
            </Link></div>
          </Grid>
        </Grid>
        <Grid container rowSpacing={1} columnSpacing={{ xs: 1, sm: 2, md: 3 }}>
          <Grid item xs={4} sx={{ mt: 5 }} className={styles.grow}>
            <img src={asset?.home2} alt="" width={300} style={{ borderRadius: "2%" }} />
            <div style={{ display: "flex" }}><Link href="/technology" style={{ textDecoration: "none" }}><Typography sx={{ fontSize: "12px", fontWeight: "bold" }}>DESIGN</Typography></Link>
              <Link href="/technology" style={{ textDecoration: "none" }}><Typography sx={{ fontSize: "12px", color: "#8F00FF", fontWeight: "bold", ml: 3 }}>LIFESTYLE</Typography></Link>
            </div>
            <Link href="/technology" style={{ textDecoration: "none" }}><Typography sx={{ fontSize: "15px", color: "black", mr: 5, fontWeight: "bold" }}>14 Architectural Design Ideas for a Spacious Interior</Typography></Link>
            <div style={{ display: "flex" }}><Link href=""><Avatar alt="Remy Sharp" src={asset?.home_avatar1} sx={{ float: "left" }} /> <Typography variant="body2" color="text.secondary" >Mario Sanchez  October 21, 2022</Typography>
            </Link></div>
          </Grid>
          <Grid item xs={4} sx={{ mt: 5 }} className={styles.grow}>
            <img src={asset?.home3} alt="" width={300} height={350} style={{ borderRadius: "2%" }} />
            <div style={{ display: "flex" }}><Link href="/technology" style={{ textDecoration: "none" }}><Typography sx={{ fontSize: "12px", fontWeight: "bold", color: "#8F00FF" }}>LIFESTYLE</Typography></Link>
              <Link href="/technology" style={{ textDecoration: "none" }}><Typography sx={{ fontSize: "12px", fontWeight: "bold", ml: 3 }}>PERSONAL GROWTH</Typography></Link>
            </div>
            <Link href="/technology" style={{ textDecoration: "none" }}><Typography sx={{ fontSize: "15px", color: "black", mr: 5, fontWeight: "bold" }}>Every Next Level of Your Life Will Demand a Different You</Typography></Link>
            <div style={{ display: "flex" }}><Link href=""><Avatar alt="Remy Sharp" src={asset?.home_avatar1} sx={{ float: "left" }} /> <Typography variant="body2" color="text.secondary" >Mario Sanchez  October 21, 2022</Typography>
            </Link></div>
          </Grid>
          <Grid item xs={4} sx={{ mt: 5 }} className={styles.grow}>
            <img src={asset?.home4} alt="" width={300} height={350} style={{ borderRadius: "2%" }} />
            <Link href="/technology" style={{ textDecoration: "none" }}><Typography sx={{ fontSize: "12px", fontWeight: "bold", color: "#FFA500" }}>TRAVEL</Typography></Link>
            <Link href="/technology" style={{ textDecoration: "none" }}><Typography sx={{ fontSize: "15px", color: "black", mr: 5, fontWeight: "bold" }}>This Bread Pudding Will Give You All the Fall Feels</Typography></Link>
            <div style={{ display: "flex" }}><Link href=""><Avatar alt="Remy Sharp" src={asset?.home_avatar1} sx={{ float: "left" }} /> <Typography variant="body2" color="text.secondary" >Mario Sanchez  October 21, 2022</Typography>
            </Link></div>
          </Grid>
        </Grid>
      </Container>
    </Wrapper>
  );
}
