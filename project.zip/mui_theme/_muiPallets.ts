export const primary = {
    main: '#f9bdab',
    light: '#ffe0c8',
    dark: '#1565c0',
    contrastText: '#893f2b',
  };
  