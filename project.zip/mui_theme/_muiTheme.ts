

export const primaryColors = {
    
}